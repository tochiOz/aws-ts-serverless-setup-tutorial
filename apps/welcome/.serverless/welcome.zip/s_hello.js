
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'tochinny',
  applicationName: 'awssetup',
  appUid: '9yJC6T27Y766cc0Z4R',
  orgUid: '646c704a-4bf1-42da-b55b-5fd78d82b8f6',
  deploymentUid: '66982922-7ce3-490d-a143-96e7809cfecb',
  serviceName: 'welcome',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'welcome-dev-hello', timeout: 100 };

try {
  const userHandler = require('./src/hello.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}